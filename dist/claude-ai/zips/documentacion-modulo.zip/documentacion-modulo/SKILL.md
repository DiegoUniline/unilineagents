---
name: documentacion-modulo
description: Plantillas y convenciones de documentación del proyecto (/docs, documento vivo 00-estado, módulo, diccionario de datos, P-XXX, D-XXX, niveles de certeza, convenciones de BD). Úsala al crear o actualizar cualquier archivo de /docs.
---

# CONVENCIONES COMPARTIDAS (arquitecto + auditor)

## Niveles de certeza
Todo campo, regla, proceso y permiso lleva uno:
- ✅ CONFIRMADO — el dueño lo dijo, o (en auditoría) se vio en BD y en código.
- 💡 PROPUESTO — decisión técnica tuya por buena práctica; requiere aprobación.
- 🟡 INFERIDO — deducido por nombre o uso parcial, sin confirmación.
- ❓ PENDIENTE / DESCONOCIDO — falta respuesta o evidencia.
- ⚠️ INCONSISTENTE — dueño, BD, front o backend se contradicen.

Conocimiento del módulo = ✅ / total × 100.

## Convenciones de base de datos (Postgres / Supabase)
- Tablas y columnas en snake_case, español, plural en tablas (`habitaciones`, `tipos_habitacion`).
- `id uuid primary key default gen_random_uuid()`.
- Multiempresa: toda tabla de negocio lleva `empresa_id uuid not null references empresas(id)`; si hay sucursales, `sucursal_id`.
- Auditoría: `created_at timestamptz default now()`, `updated_at timestamptz`, `created_by uuid`, `updated_by uuid`.
- Baja lógica por defecto: `activo boolean default true` (deshabilitar) y/o `deleted_at timestamptz` (eliminar). DELETE físico solo en registros sin historial.
- Dinero: `numeric(14,2)`. Cantidades: `numeric(14,4)`. Nunca float/real.
- Fechas con hora: `timestamptz`. Solo fecha: `date`.
- Listas FIJAS (las define el sistema): `text` + `CHECK (campo in (...))`.
- Listas CONFIGURABLES (el cliente agrega): tabla catálogo con `empresa_id`, `nombre`, `activo`, `orden`, `es_sistema boolean` (los seed con `es_sistema=true` no se borran).
- Unicidad siempre por empresa: `unique (empresa_id, codigo)`.
- Estados con máquina de estados documentada: qué transiciones son válidas y quién las ejecuta.
- Documentos que congelan valores (ventas, reservas, pedidos): copian precio, impuesto y nombre al momento; nunca dependen del valor vivo del catálogo.
- RLS activado en todas las tablas; políticas por `empresa_id` del usuario.
- Operaciones de varios pasos (cobrar, cerrar, cancelar) en función SQL (RPC) transaccional, no en pasos sueltos desde el front.

## Plantilla de módulo — /docs/modulos/<modulo>.md

```
# Módulo: <nombre>
Conocimiento: XX% (✅ n / total n) | Última actualización: <fecha> | Fuente: diseño | auditoría

## 1. Propósito
Qué problema de negocio resuelve. [certeza]

## 2. Entidades y diccionario de datos
### Tabla `<tabla>`
| Campo | Tipo | Null | Default | Qué representa | Reglas / validación | Certeza | Evidencia / origen |
|---|---|---|---|---|---|---|---|

## 3. Catálogos
| Catálogo | FIJO / CONFIGURABLE | Valores iniciales (seed) | ¿El cliente puede borrar seed? | Certeza |

## 4. Relaciones
| Campo | Apunta a | Cardinalidad | ON DELETE | Qué pasa si se da de baja el padre | Certeza |

## 5. Estados
| Estado | Significado | Pasa a | Quién lo cambia | Condición | Certeza |

## 6. Procesos
Por cada proceso: disparador, quién puede, pasos, tablas afectadas, efectos en otros módulos,
qué pasa si falla a la mitad, certeza.
### 6.1 Alta
### 6.2 Edición (¿afecta históricos? ¿documentos abiertos?)
### 6.3 Baja (lógica o física, qué pasa con lo relacionado)
### 6.4 Reactivación
### 6.5 Procesos propios del módulo

## 7. Qué pasa si… (casos borde)
| # | Escenario | Comportamiento esperado | Certeza |

## 8. Permisos
| Acción | Roles | Validado en UI | Validado en BD (RLS/función) | Certeza |

## 8b. Consultas y escalabilidad
| Consulta / pantalla | Filtros y orden | Índice que la soporta | Volumen 1 año | Volumen 3 años | Estrategia |

## 9. Criterios de aceptación
Ejemplos concretos verificables: "Dado… cuando… entonces…".

## 10. Inconsistencias ⚠️
| # | Descripción | Dónde | Impacto | Severidad |

## 11. Preguntas abiertas
Referencias a P-XXX.
```

## Formato de preguntas — /docs/preguntas.md
```
### P-001 · <módulo> · ALTA|MEDIA|BAJA · ABIERTA|RESPONDIDA
**Contexto:** qué sabes y por qué importa.
**Pregunta:** concreta, de negocio, respondible en una línea.
**Opciones:** A) …  B) …  C) otra
**Recomendación:** X — por qué en una línea.
**Impacto en datos:** qué tablas/campos cambian según la respuesta.
**Respuesta:** (vacío hasta que conteste)
```

## Formato de decisiones — /docs/decisiones.md
```
### D-001 · <módulo> · <fecha>
**Decisión:** …
**Origen:** P-XXX | propuesta aprobada | auditoría
**Consecuencias:** qué implica en datos y procesos.
```

## Estructura de /docs
```
/docs/00-estado.md        DOCUMENTO VIVO: fase, módulo en curso, última pregunta, siguiente paso, pendientes
/docs/bitacora.md         una línea por evento, solo se agrega
/docs/investigacion-giro.md  investigación del giro con fuentes (🟡 hasta que el dueño confirme)
/docs/00-vision.md        visión, usuarios, alcance v1 / fuera de alcance
/docs/funciones.md        catálogo de funciones por módulo: v1, después, descartadas
/docs/sistema-diseno.md   colores, tipografía, tokens y reglas de formularios, tablas, botones y mensajes
/docs/00-mapa.md          módulos, tablas, relaciones entre módulos, % conocimiento por módulo
/docs/modulos/*.md        un archivo por módulo (plantilla de arriba)
/docs/preguntas.md        todas las preguntas P-XXX
/docs/decisiones.md       todas las decisiones D-XXX
/docs/riesgos.md          riesgos por severidad (auditoría)
/docs/glosario.md         términos del negocio y su significado exacto
/docs/diagrama-er.md      diagrama entidad-relación (Mermaid)
/docs/ordenes/OT-XXX.md   órdenes de trabajo: el pedido del dueño convertido en prompt preciso
```

Si no tienes acceso a archivos (chat web), entrega cada archivo como bloque de código con su ruta como título para que el usuario lo guarde.

## Plantilla /docs/00-estado.md
# Estado del proyecto — DOCUMENTO VIVO
> Se lee al iniciar cada sesión y se actualiza después de cada respuesta, decisión, cambio o hallazgo.

**Última actualización:** <fecha y hora> · **Agente:** <arquitecto | auditor | desarrollador | qa>

## Dónde vamos
- **Fase:** <−1 investigación | 0 visión | 1 entrevista | 2 propuesta | 3 generación | auditoría | desarrollo>
- **Módulo en curso:** <nombre>
- **Última pregunta:** P-XXX — <texto corto> — <ABIERTA | RESPONDIDA: respuesta>
- **Siguiente paso exacto:** <qué sigue, en una línea>

## Decisiones recientes (últimas 10)
- D-XXX · <módulo> · <decisión en una línea>

## Propuestas pendientes de aprobación 💡
- <propuesta> — <por qué>

## Pendientes / bloqueos
- <pendiente>

## Módulos
| módulo | fuente | fase | % conocimiento | ❓ abiertas |
|---|---|---|---|---|
